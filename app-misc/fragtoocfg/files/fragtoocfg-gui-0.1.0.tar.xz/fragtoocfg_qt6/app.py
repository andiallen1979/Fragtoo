import os, shutil, subprocess, sys
from pathlib import Path
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QGroupBox, QHBoxLayout, QInputDialog, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QTreeWidget, QTreeWidgetItem,
    QPushButton, QRadioButton, QScrollArea, QSplitter, QTabWidget,
    QTextEdit, QVBoxLayout, QWidget,
)
from fragtoocfg.portage_io import ENV_PROFILES_DIR, PORTAGE_DIR, collect_portage_state, ensure_gentoo_os, render_env_vars
from fragtoocfg.cli import write_one

INFO_CHEATSHEET = """=== PER-PACKAGE PORTAGE QUICK REFERENCE ===

0. Package Tree Status Badges
   USE   = Custom per-package flags in /etc/portage/package.use
   ENV   = Custom build profile in /etc/portage/package.env
   KW    = Custom keyword rule (~amd64 / amd64 / **) in package.accept_keywords
   MASK  = Version or package block in /etc/portage/package.mask
   PATCH = Active user patch in /etc/portage/patches/<cat>/<pkg>/

1. package.use (/etc/portage/package.use/<cat>/<pkg>)
   lto           Enable Link-Time Optimization (faster binary, high link RAM)
   pgo           Enable Profile-Guided Optimization (longer compile, faster binary)
   custom-cflags Respect user CFLAGS/CXXFLAGS instead of stripping them
   system-llvm   Link against system LLVM instead of bundled LLVM

2. package.env (/etc/portage/env/*.conf -> /etc/portage/package.env/<cat>/<pkg>)
   MAKEOPTS="-j8 -l8"  |  NINJAFLAGS="-j8 -l8"  |  CARGO_BUILD_JOBS="8"
   LDFLAGS="${LDFLAGS} -fuse-ld=mold"  (Use fast mold linker)
   CFLAGS="${CFLAGS} -fno-lto"         (Disable LTO for RAM-heavy builds)
   PORTAGE_TMPDIR="/var/tmp"           (Build on disk instead of tmpfs)

3. package.accept_keywords (/etc/portage/package.accept_keywords/<cat>/<pkg>)
   amd64 (stable)  |  ~amd64 (testing)  |  ** (missing / live -9999 keywords)
   Scopes: cat/pkg (all) | =cat/pkg-ver (exact) | >=cat/pkg-ver (forward)

4. package.mask (/etc/portage/package.mask/<cat>/<pkg>)
   Unmasked | cat/pkg (all) | =cat/pkg-ver (exact) | >=cat/pkg-ver (forward)

5. User Patches (/etc/portage/patches/<cat>/<pkg>/)
   *.patch / *.diff (active in src_prepare) <-> *.patch.disabled (skipped)
"""

class PortageStore:
    def __init__(self) -> None:
        self.state = collect_portage_state()
        self.pkg_map = {p["cp"]: p for p in self.state["packages"]}
        for p in self.state["packages"]:
            p["cur_flags"] = {f["flag"]: f["effective"] for f in p["flags"]}
            p["cur_envs"] = {e["name"] for e in p["envs"] if e["initial"]}
            p["cur_kw"] = {"amd64": p.get("kw_s", False), "~amd64": p["kw_t"], "**": p["kw_l"]}
            p["cur_kw_mode"] = p.get("kw_mode", "ALL")
            p["cur_mask"] = p["mask_mode"]
            p["cur_unmask"] = p.get("unmask_mode", "NONE")
            for pt in p["patches"]: pt["cur_en"] = pt["enabled"]
            p["new_patches"] = []

    def build_sanity_report(self) -> tuple[list[str], list[str]]:
        critical_pkgs = {"sys-libs/glibc", "sys-devel/gcc", "sys-apps/portage", "sys-apps/systemd", "sys-apps/openrc", "dev-lang/python", "llvm-core/llvm", "dev-lang/rust"}
        changes, warnings = [], []
        for p in self.state.get("packages", ()):
            cp = p.get("cp")
            orig_use = {f.get("flag"): f.get("effective") for f in p.get("flags", ())}
            cur_use = p.get("cur_flags", {})
            if cur_use != orig_use:
                diffs = [f"{'+' if cur_use.get(k) else '-'}{k}" for k in sorted(cur_use) if cur_use.get(k) != orig_use.get(k)]
                changes.append(f"[package.use] {cp}: {' '.join(diffs)}")
                for f in p.get("flags", ()):
                    fl = f.get("flag")
                    if f.get("forced") and cur_use.get(fl) != orig_use.get(fl):
                        warnings.append(f"HIGH RISK: Modifying profile-locked flag '{fl}' on {cp} ({f.get('force_reason')}).")
            orig_env = {e.get("name") for e in p.get("envs", ()) if e.get("initial")}
            if p.get("cur_envs", set()) != orig_env:
                changes.append(f"[package.env] {cp}: {' '.join(sorted(p.get('cur_envs', set()))) or '(cleared)'}")
            orig_kw = {"amd64": p.get("kw_s", False), "~amd64": p.get("kw_t", False), "**": p.get("kw_l", False)}
            cur_kw = p.get("cur_kw", {})
            if cur_kw != orig_kw or (p.get("cur_kw_mode") != p.get("kw_mode") and any(cur_kw.values())):
                kws = [k for k in ("amd64", "~amd64", "**") if cur_kw.get(k)]
                changes.append(f"[package.accept_keywords] {cp} ({p.get('cur_kw_mode')}): {' '.join(kws) or '(cleared)'}")
                if cur_kw.get("**") and not orig_kw.get("**"):
                    warnings.append(f"BINHOST RISK: Adding '**' keyword to {cp} allows live/untested ebuilds.")
            if p.get("cur_unmask") != p.get("unmask_mode", "NONE"):
                changes.append(f"[package.unmask] {cp}: {p.get('unmask_mode', 'NONE')} -> {p.get('cur_unmask')}")
            if p.get("cur_mask") != p.get("mask_mode"):
                changes.append(f"[package.mask] {cp}: {p.get('mask_mode')} -> {p.get('cur_mask')}")
                if p.get("cur_mask") != "NONE" and cp in critical_pkgs:
                    warnings.append(f"CRITICAL SYSTEM RISK: Masking core package {cp} can break system or binhost builds.")
            for pt in p.get("patches", ()):
                if pt.get("cur_en") != pt.get("enabled"):
                    changes.append(f"[patches] {cp}/{pt.get('base_name')}: {'ENABLE' if pt.get('cur_en') else 'DISABLE'}")
            for np in p.get("new_patches", ()):
                changes.append(f"[patches] {cp}: ADD {Path(np).name}")
        return changes, warnings

    def save_all(self) -> int:
        is_root = os.geteuid() == 0
        base = PORTAGE_DIR if is_root else (Path.cwd() / "portage-preview")
        changed = 0
        for p in self.state["packages"]:
            cp, cat, name = p["cp"], p["cat"], p["name"]
            # package.use
            orig_use = {f["flag"]: f["effective"] for f in p["flags"]}
            if p["cur_flags"] != orig_use:
                changed += 1
                duse = {f["flag"]: p["cur_flags"][f["flag"]] for f in p["flags"] if p["cur_flags"][f["flag"]] != f["installed"]}
                write_one(base / "package.use" / cat / name, f"{cp} {' '.join(f'{'' if duse[k] else '-'}{k}' for k in sorted(duse))}" if duse else None)
            # package.env
            orig_env = {e["name"] for e in p["envs"] if e["initial"]}
            if p["cur_envs"] != orig_env:
                changed += 1
                write_one(base / "package.env" / cat / name, f"{cp} {' '.join(sorted(p['cur_envs']))}" if p["cur_envs"] else None)
            # package.accept_keywords
            orig_kw = {"amd64": p.get("kw_s", False), "~amd64": p["kw_t"], "**": p["kw_l"]}
            if p["cur_kw"] != orig_kw or (p["cur_kw_mode"] != p.get("kw_mode", "ALL") and any(p["cur_kw"].values())):
                changed += 1
                kws = [k for k in ("amd64", "~amd64", "**") if p["cur_kw"][k]]
                km = p["cur_kw_mode"]
                ka = cp if km == "ALL" else ((p.get("kw_atom", f"={p['cpv']}") if p.get("kw_mode") == "EQ" else f"={p['cpv']}") if km == "EQ" else (p.get("kw_atom", f">={p['cpv']}") if p.get("kw_mode") == "FWD" else f">={p['cpv']}"))
                write_one(base / "package.accept_keywords" / cat / name, f"{ka} {' '.join(kws)}" if kws else None)
            # package.unmask
            if p.get("cur_unmask") != p.get("unmask_mode", "NONE"):
                changed += 1; num = p.get("cur_unmask")
                ua = None if num == "NONE" else (cp if num == "ALL" else (f"={p.get('cpv')}" if num == "EQ" else f">={p.get('cpv')}"))
                write_one(base / "package.unmask" / cat / name, ua)
            # package.mask
            if p["cur_mask"] != p["mask_mode"]:
                changed += 1
                nm = p["cur_mask"]
                na = None if nm == "NONE" else (cp if nm == "ALL" else (f"={p['cpv']}" if nm == "EQ" else f">={p['cpv']}"))
                write_one(base / "package.mask" / cat / name, na)
            # patches
            pdir = base / "patches" / cat / name
            for pt in p["patches"]:
                if pt["cur_en"] != pt["enabled"]:
                    changed += 1; pdir.mkdir(parents=True, exist_ok=True)
                    dst = pdir / (pt["base_name"] if pt["cur_en"] else f"{pt['base_name']}.disabled")
                    if is_root and pt["path"].is_file(): pt["path"].rename(dst)
            for src_file in p["new_patches"]:
                changed += 1; pdir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_file, pdir / Path(src_file).name)
        return changed

class fragtooCfgWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("fragtoo Portage Configurator (fragtoocfg-qt6)")
        self.resize(1180, 760)
        self.store = PortageStore()
        self.cur_pkg: dict | None = None
        root = QWidget(); self.setCentralWidget(root)
        main_lay = QVBoxLayout(root)
        splitter = QSplitter(Qt.Orientation.Horizontal); main_lay.addWidget(splitter, 1)

        # Left Pane: Filter, Sort & Package List
        left = QWidget(); l_lay = QVBoxLayout(left)
        self.search_box = QLineEdit(); self.search_box.setPlaceholderText("Filter packages (name, category, USE, ENV, PATCH)...")
        self.search_box.textChanged.connect(self.refresh_pkg_list); l_lay.addWidget(self.search_box)
        self.sort_slowest = QCheckBox("Sort by longest genlop -t build time first")
        self.sort_slowest.toggled.connect(self.refresh_pkg_list); l_lay.addWidget(self.sort_slowest)
        self.pkg_tree = QTreeWidget(); self.pkg_tree.setHeaderLabels(("Package", "Info / Active Overrides"))
        self.pkg_tree.setColumnWidth(0, 210); self.pkg_tree.currentItemChanged.connect(self.on_pkg_selected)
        l_lay.addWidget(self.pkg_tree, 1)
        legend = QLabel("Badges: USE = package.use | ENV = package.env | KW = accept_keywords | MASK = package.mask | PATCH = patches")
        legend.setWordWrap(True); legend.setStyleSheet("color: gray; font-size: 11px;")
        l_lay.addWidget(legend)
        splitter.addWidget(left)

        # Right Pane: Header + Tabs
        right = QWidget(); r_lay = QVBoxLayout(right)
        self.hdr_label = QLabel("Select a package on the left to inspect and configure."); self.hdr_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        r_lay.addWidget(self.hdr_label)

        self.tabs = QTabWidget(); r_lay.addWidget(self.tabs, 1)
        # Tab 1: USE Flags
        t_use = QWidget(); u_lay = QVBoxLayout(t_use)
        u_top = QHBoxLayout()
        self.use_filter = QLineEdit(); self.use_filter.setPlaceholderText("Filter USE flags...")
        self.use_filter.textChanged.connect(self.rebuild_use_tab)
        btn_ref = QPushButton("Refresh"); btn_ref.clicked.connect(self.reload_portage_state)
        u_top.addWidget(self.use_filter, 1); u_top.addWidget(btn_ref); u_lay.addLayout(u_top)
        self.use_scroll = QScrollArea(); self.use_scroll.setWidgetResizable(True); u_lay.addWidget(self.use_scroll, 1)
        self.tabs.addTab(t_use, "USE")

        # Tab 2: Unified Environment (package.env + /etc/portage/env Editor)
        t_env = QSplitter(Qt.Orientation.Horizontal)
        env_left = QWidget(); el_lay = QVBoxLayout(env_left)
        el_lay.addWidget(QLabel("Assign /etc/portage/env profiles to package:"))
        self.env_scroll = QScrollArea(); self.env_scroll.setWidgetResizable(True); el_lay.addWidget(self.env_scroll, 1)
        t_env.addWidget(env_left)

        env_right = QWidget(); er_lay = QVBoxLayout(env_right)
        top_bar = QHBoxLayout()
        self.active_env_name = ""
        self.env_name_edit = QLineEdit(); self.env_name_edit.setPlaceholderText("Select or enter profile.conf...")
        btn_new = QPushButton("+"); btn_new.setFixedWidth(32); btn_new.setToolTip("Create new /etc/portage/env/*.conf file"); btn_new.clicked.connect(self.create_new_env_file)
        btn_save_env = QPushButton("Save"); btn_save_env.setFixedWidth(64); btn_save_env.clicked.connect(self.save_env_file_text)
        btn_del = QPushButton("Delete"); btn_del.setFixedWidth(64); btn_del.clicked.connect(self.delete_env_file)
        top_bar.addWidget(self.env_name_edit, 1); top_bar.addWidget(btn_new); top_bar.addWidget(btn_save_env); top_bar.addWidget(btn_del)
        er_lay.addLayout(top_bar)
        self.env_editor = QTextEdit(); self.env_editor.setStyleSheet("font-family: monospace; font-size: 13px;")
        er_lay.addWidget(self.env_editor, 1)
        t_env.addWidget(env_right); t_env.setSizes((320, 480))
        self.tabs.addTab(t_env, "Environment")

        # Tab 3: Keywords & Masking
        self.kw_scroll = QScrollArea(); self.kw_scroll.setWidgetResizable(True)
        self.tabs.addTab(self.kw_scroll, "Keywords")

        # Tab 4: Patches
        t_pat = QWidget(); p_lay = QVBoxLayout(t_pat)
        add_btn = QPushButton("Add Patch File to /etc/portage/patches/<cat>/<pkg>/..."); add_btn.clicked.connect(self.add_patch_dialog); p_lay.addWidget(add_btn)
        self.pat_scroll = QScrollArea(); self.pat_scroll.setWidgetResizable(True); p_lay.addWidget(self.pat_scroll, 1)
        self.tabs.addTab(t_pat, "Patches")

        # Tab 5: Info & Cheat-Sheet
        info_txt = QTextEdit(); info_txt.setReadOnly(True); info_txt.setPlainText(INFO_CHEATSHEET)
        self.tabs.addTab(info_txt, "Info")

        self.reload_env_combo()

        splitter.addWidget(right); splitter.setSizes([380, 800])
        self.stack_box = QTextEdit(); self.stack_box.setReadOnly(True); self.stack_box.setMaximumHeight(72)
        main_lay.addWidget(self.stack_box)
        bot_bar = QHBoxLayout(); bot_bar.addStretch(1)
        save_btn = QPushButton("Save"); save_btn.setFixedWidth(96)
        save_btn.clicked.connect(self.on_save_clicked); bot_bar.addWidget(save_btn)
        main_lay.addLayout(bot_bar)
        self.refresh_pkg_list()

    def _make_pkg_node(self, p: dict) -> QTreeWidgetItem:
        badges = ([p.get("build_fmt")] if p.get("build_secs", 0) > 0 else []) + (["USE"] if p.get("use_mod") else []) + (["ENV"] if p.get("cur_envs") else []) + (["KW"] if any(p.get("cur_kw", {}).values()) else []) + ((["MASK"] if p.get("cur_mask") != "NONE" else []) + (["UNMASK"] if p.get("cur_unmask", "NONE") != "NONE" else [])) + (["PATCH"] if (p.get("has_patch") or p.get("new_patches")) else [])
        node = QTreeWidgetItem((p.get("name"), " | ".join(badges)))
        node.setData(0, Qt.ItemDataRole.UserRole, p.get("cp"))
        return node

    def refresh_pkg_list(self) -> None:
        q = self.search_box.text().strip().lower()
        self.pkg_tree.clear()
        pkgs = self.store.state.get("packages", ())
        if self.sort_slowest.isChecked():
            slow = sorted((x for x in pkgs if x.get("build_secs", 0) > 0), key=lambda x: (-x.get("build_secs", 0), x.get("cp")))
            if slow:
                top_grp = QTreeWidgetItem((f"Top Slowest Builds ({len(slow)})", "Sorted by genlop -t"))
                for p in slow:
                    nd = self._make_pkg_node(p)
                    if not q or q in f"{p.get('cp')} {nd.text(1)}".lower(): top_grp.addChild(nd)
                if top_grp.childCount() > 0:
                    self.pkg_tree.addTopLevelItem(top_grp); top_grp.setExpanded(True)
        by_cat = {}
        for p in pkgs: by_cat.setdefault(p.get("cat"), []).append(p)
        for cat in sorted(by_cat):
            grp = QTreeWidgetItem((cat, ""))
            for p in by_cat.get(cat, ()):
                nd = self._make_pkg_node(p)
                if not q or q in f"{p.get('cp')} {nd.text(1)}".lower(): grp.addChild(nd)
            if grp.childCount() > 0:
                grp.setText(0, f"{cat} ({grp.childCount()})")
                self.pkg_tree.addTopLevelItem(grp)
                if q: grp.setExpanded(True)

    def on_pkg_selected(self, cur: QTreeWidgetItem | None, _prev=None) -> None:
        if not cur: return
        cp = cur.data(0, Qt.ItemDataRole.UserRole)
        if not cp: return
        p = self.store.pkg_map.get(cp)
        if not p: return
        self.cur_pkg = p
        self.hdr_label.setText(f"{p['cpv']}   |   Last merge: {p['build_fmt']}")
        self.stack_box.setPlainText(f"Active USE Stack: {p['use_stack']}")
        self.rebuild_use_tab(); self.rebuild_env_tab(); self.rebuild_kw_tab(); self.rebuild_patch_tab()

    def reload_portage_state(self) -> None:
        cur_cp = self.cur_pkg.get("cp") if self.cur_pkg else None
        self.store = PortageStore()
        self.refresh_pkg_list()
        if cur_cp and cur_cp in self.store.pkg_map:
            self.cur_pkg = self.store.pkg_map.get(cur_cp)
            self.hdr_label.setText(f"{self.cur_pkg.get('cpv')}   |   Last merge: {self.cur_pkg.get('build_fmt')}")
            self.stack_box.setPlainText(f"Active USE Stack: {self.cur_pkg.get('use_stack')}")
            self.rebuild_use_tab(); self.rebuild_env_tab(); self.rebuild_kw_tab(); self.rebuild_patch_tab()

    def rebuild_use_tab(self) -> None:
        w = QWidget(); lay = QVBoxLayout(w)
        if not self.cur_pkg or not self.cur_pkg["flags"]:
            lay.addWidget(QLabel("No configurable IUSE flags for this package.")); lay.addStretch(); self.use_scroll.setWidget(w); return
        qf = self.use_filter.text().strip().lower(); p = self.cur_pkg
        for f in p["flags"]:
            if qf and qf not in f["flag"].lower(): continue
            cb = QCheckBox(f"{f.get('flag')} *" if f.get("forced") else f.get("flag"))
            if f.get("forced"): cb.setToolTip("Profile-forced or masked flag (altering not recommended)")
            cb.setChecked(p["cur_flags"][f["flag"]])
            cb.toggled.connect(lambda chk, fl=f.get("flag"), meta=f, box=cb, pkg=p: self.on_use_toggled(chk, fl, meta, box, pkg))
            lay.addWidget(cb)
        lay.addStretch(); self.use_scroll.setWidget(w)

    def on_use_toggled(self, chk: bool, fl: str, meta: dict, box: QCheckBox, pkg: dict) -> None:
        if meta.get("forced"):
            reason = meta.get("force_reason", "locked by your active Portage profile")
            ans = QMessageBox.warning(
                self, "Profile-Locked USE Flag",
                f"'{fl}' on {pkg.get('cp')} is {reason}.\n\nAltering profile-locked flags can break core dependencies or cause Portage conflicts.\n\nApply this override anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if ans != QMessageBox.StandardButton.Yes:
                box.blockSignals(True); box.setChecked(not chk); box.blockSignals(False)
                return
        pkg.get("cur_flags").update({fl: chk})

    def rebuild_env_tab(self) -> None:
        w = QWidget(); lay = QVBoxLayout(w)
        if not self.cur_pkg: return
        p = self.cur_pkg
        if not p["envs"]: lay.addWidget(QLabel("No /etc/portage/env/*.conf profiles defined yet."))
        for e in p.get("envs", ()):
            en = e.get("name")
            row = QHBoxLayout()
            cb = QCheckBox()
            cb.setChecked(en in p.get("cur_envs", set()))
            cb.toggled.connect(lambda chk, name=en, pkg=p: (pkg.get("cur_envs").add(name) if chk else pkg.get("cur_envs").discard(name)))
            lbl_btn = QPushButton(en)
            lbl_btn.setFlat(True)
            lbl_btn.setStyleSheet("text-align: left; padding: 2px;")
            lbl_btn.clicked.connect(lambda _=False, name=en: self.load_env_file_text(name))
            row.addWidget(cb); row.addWidget(lbl_btn, 1)
            lay.addLayout(row)
        lay.addStretch(); self.env_scroll.setWidget(w)
        if p.get("cur_envs"):
            self.load_env_file_text(sorted(p.get("cur_envs"))[-1])

    def rebuild_kw_tab(self) -> None:
        w = QWidget(); lay = QVBoxLayout(w)
        if not self.cur_pkg: return
        p = self.cur_pkg
        gb_kw = QGroupBox("Accepted Keywords (package.accept_keywords)"); kl = QVBoxLayout(gb_kw)
        for kw, desc in [("amd64", "Accept amd64 (stable)"), ("~amd64", "Accept ~amd64 (testing)"), ("**", "Accept ** (missing / live -9999 keywords)")]:
            cb = QCheckBox(desc); cb.setChecked(p["cur_kw"][kw])
            cb.toggled.connect(lambda chk, k=kw, pkg=p: pkg["cur_kw"].update({k: chk})); kl.addWidget(cb)
        gb_sc = QGroupBox("Keyword Atom Scope"); sl = QVBoxLayout(gb_sc)
        for mode, lbl in [("ALL", f"All versions ({p['cp']})"), ("EQ", f"Exact version (={p['cpv']})"), ("FWD", f"Forward upgrades (>={p['cpv']})")]:
            rb = QRadioButton(lbl); rb.setChecked(p["cur_kw_mode"] == mode)
            rb.toggled.connect(lambda chk, m=mode, pkg=p: pkg.update({"cur_kw_mode": m}) if chk else None); sl.addWidget(rb)
        gb_mk = QGroupBox("Package Masking (package.mask)"); ml = QVBoxLayout(gb_mk)
        for mode, lbl in [("NONE", "Unmasked"), ("ALL", f"All versions ({p['cp']})"), ("EQ", f"Exact version (={p['cpv']})"), ("FWD", f"Forward upgrades (>={p['cpv']})")]:
            rb = QRadioButton(lbl); rb.setChecked(p["cur_mask"] == mode)
            rb.toggled.connect(lambda chk, m=mode, pkg=p: pkg.update({"cur_mask": m}) if chk else None); ml.addWidget(rb)
        gb_um = QGroupBox("Package Unmasking (package.unmask)"); ul = QVBoxLayout(gb_um)
        for mode, lbl in (("NONE", "Default (no local unmask)"), ("ALL", f"Unmask all versions ({p.get('cp')})"), ("EQ", f"Unmask exact version (={p.get('cpv')})"), ("FWD", f"Unmask forward (>={p.get('cpv')})")):
            rb = QRadioButton(lbl); rb.setChecked(p.get("cur_unmask") == mode)
            rb.toggled.connect(lambda chk, m=mode, pkg=p: pkg.update({"cur_unmask": m}) if chk else None); ul.addWidget(rb)
        lay.addWidget(gb_kw); lay.addWidget(gb_sc); lay.addWidget(gb_mk); lay.addWidget(gb_um); lay.addStretch(); self.kw_scroll.setWidget(w)

    def rebuild_patch_tab(self) -> None:
        w = QWidget(); lay = QVBoxLayout(w)
        if not self.cur_pkg: return
        p = self.cur_pkg
        if not p["patches"] and not p["new_patches"]: lay.addWidget(QLabel(f"No patches in /etc/portage/patches/{p['cp']}/"))
        for pt in p["patches"]:
            cb = QCheckBox(f"Enable patch: {pt['base_name']}"); cb.setChecked(pt["cur_en"])
            cb.toggled.connect(lambda chk, item=pt: item.update({"cur_en": chk})); lay.addWidget(cb)
        for np in p["new_patches"]: lay.addWidget(QLabel(f"[Queued to copy on save] {Path(np).name}"))
        lay.addStretch(); self.pat_scroll.setWidget(w)

    def add_patch_dialog(self) -> None:
        if not self.cur_pkg: return
        fn, _ = QFileDialog.getOpenFileName(self, "Select Patch File", str(Path.home()), "Patches (*.patch *.diff);;All Files (*)")
        if fn: self.cur_pkg["new_patches"].append(fn); self.rebuild_patch_tab(); self.refresh_pkg_list()


    def _env_dir(self) -> Path:
        return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")

    def reload_env_combo(self, select_name: str = "") -> None:
        self.load_env_file_text(select_name or self.active_env_name)

    def load_env_file_text(self, fname: str) -> None:
        self.active_env_name = fname or ""
        if not self.active_env_name:
            self.env_name_edit.clear()
            self.env_editor.clear()
            return
        self.env_name_edit.setText(self.active_env_name)
        local_f = self._env_dir() / self.active_env_name
        sys_f = ENV_PROFILES_DIR / self.active_env_name
        target = local_f if local_f.is_file() else sys_f
        self.env_editor.setPlainText(target.read_text(encoding="utf-8", errors="ignore") if target.is_file() else "")

    def create_new_env_file(self) -> None:
        name, ok = QInputDialog.getText(self, "New /etc/portage/env Profile", "Filename (e.g. mem-heavy.conf):")
        if not ok or not name.strip(): return
        fn = name.strip() if name.strip().endswith(".conf") else f"{name.strip()}.conf"
        d = self._env_dir(); d.mkdir(parents=True, exist_ok=True); f = d / Path(fn).name
        if not f.exists(): f.write_text('MAKEOPTS="-j8 -l8"\nNINJAFLAGS="-j8 -l8"\nCARGO_BUILD_JOBS="8"\n', encoding="utf-8")
        self.reload_env_combo(f.name); self.sync_env_profiles_to_packages()

    def save_env_file_text(self) -> None:
        raw_fn = self.env_name_edit.text().strip()
        if not raw_fn: return
        fn = Path(raw_fn if raw_fn.endswith(".conf") else f"{raw_fn}.conf").name
        old_fn = self.active_env_name.strip()
        d = self._env_dir(); d.mkdir(parents=True, exist_ok=True)
        if old_fn and old_fn != fn:
            (d / old_fn).unlink(missing_ok=True)
            for pkg in self.store.state.get("packages", ()):
                for item in pkg.get("envs", ()):
                    if item.get("name") == old_fn: item.update({"name": fn})
                if old_fn in pkg.get("cur_envs", set()):
                    pkg.get("cur_envs").discard(old_fn); pkg.get("cur_envs").add(fn)
        body = self.env_editor.toPlainText()
        (d / fn).write_text(body if body.endswith("\n") else (body + "\n"), encoding="utf-8")
        self.active_env_name = fn; self.env_name_edit.setText(fn)
        self.sync_env_profiles_to_packages()
        QMessageBox.information(self, "Saved", f"Saved {d / fn}")

    def rename_env_file(self) -> None:
        old_fn = self.active_env_name.strip()
        if not old_fn: return
        new_in, ok = QInputDialog.getText(self, "Rename Environment Profile", f"Rename '{old_fn}' to:", text=old_fn)
        if not ok or not new_in.strip(): return
        new_fn = Path(new_in.strip() if new_in.strip().endswith(".conf") else f"{new_in.strip()}.conf").name
        if new_fn == old_fn: return
        d = self._env_dir(); d.mkdir(parents=True, exist_ok=True)
        src = (d / old_fn) if (d / old_fn).is_file() else (ENV_PROFILES_DIR / old_fn)
        dst = d / new_fn
        if dst.exists():
            QMessageBox.warning(self, "Exists", f"'{new_fn}' already exists."); return
        if src.is_file():
            dst.write_text(src.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
            if src.parent == d: src.unlink(missing_ok=True)
        for pkg in self.store.state.get("packages", ()):
            for item in pkg.get("envs", ()):
                if item.get("name") == old_fn: item.update({"name": new_fn})
            if old_fn in pkg.get("cur_envs", set()):
                pkg.get("cur_envs").discard(old_fn); pkg.get("cur_envs").add(new_fn)
        self.reload_env_combo(new_fn); self.rebuild_env_tab()

    def delete_env_file(self) -> None:
        fn = self.active_env_name.strip()
        if not fn: return
        (self._env_dir() / fn).unlink(missing_ok=True)
        self.reload_env_combo(); self.sync_env_profiles_to_packages()

    def sync_env_profiles_to_packages(self) -> None:
        d = self._env_dir()
        avail = sorted(f.name for f in d.iterdir() if f.is_file() and f.name.endswith(".conf")) if d.is_dir() else []
        for pkg in self.store.state["packages"]:
            known = {e["name"] for e in pkg["envs"]}
            for fn in avail:
                if fn not in known: pkg["envs"].append({"name": fn, "initial": False, "sym": ""})
        self.rebuild_env_tab()

    def on_save_clicked(self) -> None:
        changes, warnings = self.store.build_sanity_report()
        if not changes:
            QMessageBox.information(self, "fragtoo Portage Configurator", "No pending changes to save.")
            return
        target_root = "/etc/portage" if os.geteuid() == 0 else str(Path.cwd() / "portage-preview")
        box = QMessageBox(self)
        box.setWindowTitle("Pre-Save Sanity Check & Change Report")
        box.setIcon(QMessageBox.Icon.Warning if warnings else QMessageBox.Icon.Question)
        hdr = f"Target directory: {target_root}\nPending changes: {len(changes)}"
        if warnings:
            hdr += f"\nWARNINGS DETECTED: {len(warnings)} (Review carefully before writing!)"
        box.setText(hdr)
        detail_lines = ([] if not warnings else ["=== RISK WARNINGS ==="] + warnings + [""]) + ["=== PENDING CHANGES ==="] + changes
        box.setDetailedText("\n".join(detail_lines))
        box.setStandardButtons(QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(QMessageBox.StandardButton.Cancel if warnings else QMessageBox.StandardButton.Save)
        if box.exec() != QMessageBox.StandardButton.Save:
            self.stack_box.setPlainText("Save cancelled during sanity check. No files were modified.")
            return
        n = self.store.save_all()
        summary = f"Saved {n} change(s) to {target_root}:\n" + "\n".join(changes)
        self.stack_box.setPlainText(summary)
        self.reload_portage_state()
        if os.geteuid() != 0:
            QMessageBox.information(self, "Saved Preview", f"Applied {n} change(s) to {target_root} (non-root preview mode).")
            return
        run_ans = QMessageBox.question(
            self, "Launch Emerge in Konsole",
            f"Applied {n} change(s) to {target_root}.\n\nOpen Konsole and run 'emerge -auDN @world' now?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if run_ans == QMessageBox.StandardButton.Yes:
            try:
                subprocess.Popen(("konsole", "--hold", "-e", "emerge", "-auDN", "@world"))
            except FileNotFoundError:
                QMessageBox.critical(self, "Konsole Not Found", "Could not execute 'konsole'. Ensure kde-apps/konsole is installed.")

def main() -> None:
    app = QApplication(sys.argv)
    app.setDesktopFileName("fragtoocfg-qt6")
    win = fragtooCfgWindow(); win.show()
    sys.exit(app.exec())

if __name__ == "__main__": main()
